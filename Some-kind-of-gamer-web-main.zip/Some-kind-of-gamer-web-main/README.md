this is only a schoold project, so dont mind, keep your path stranger
